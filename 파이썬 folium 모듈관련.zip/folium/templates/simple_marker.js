var {{ marker }} = L.marker([{{ lat }}, 
							{{ lon }}],
							{{icon}}
							);